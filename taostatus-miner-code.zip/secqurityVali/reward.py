from __future__ import annotations

"""secqurityVali/reward.py - turn a Verdict into a validator reward.

The bridge between the submission pipeline (which produces a Verdict) and the
Bittensor weight machinery (which wants a number per miner). Pure and
stdlib-only, so the mapping is unit-tested here rather than discovered on a
live validator.

For this milestone the reward is binary: a submission that passed every check
earns 1.0, one that failed on its own merits earns 0.0. When the SQLi
evaluation loop lands, `reward_for_verdict` is where the graded
task_score.score (0.0-1.0) replaces the binary pass/fail -- the neuron above it
does not change.

The important distinction is the third case: a verdict that failed because the
*validator* broke (Docker down, internal error) is not a judgement about the
miner at all. It returns None -- "do not score this round" -- so a validator
outage never records a zero against a miner who did nothing wrong.
"""

from masxai import constants as C
from secqurityVali.models import Verdict

REWARD_PASS = 1.0
REWARD_FAIL = 0.0


def _efficiency_factor(request_count: int) -> float:
    """Scale a correct run by how few requests it took. A surgical agent (<=
    target requests) keeps full credit; a brute-forcer is scaled down toward the
    floor. request_count is the agent's own behaviour -- roughly deterministic and
    EMA-smoothed -- so this does not fracture multi-validator consensus the way a
    wall-clock speed term would. Returns a multiplier in [FLOOR, 1.0]."""
    floor = C.SECURITY_EFFICIENCY_FLOOR
    target = max(1, C.SECURITY_EFFICIENCY_TARGET_REQUESTS)
    n = int(request_count or 0)
    if n <= 0:
        return 1.0                        # nothing to penalise (shouldn't happen on a real solve)
    efficiency = min(1.0, target / n)     # <= target requests -> 1.0; more -> less
    return floor + (1.0 - floor) * efficiency


def reward_for_verdict(verdict: Verdict) -> float | None:
    """Map one Verdict to a reward.

    Returns:
        1.0   the submission was accepted
        0.0   the submission was rejected on its own merits
        None  the run failed on our side (retryable) -- do not score
    """
    if verdict.validator_fault:
        return None
    return REWARD_PASS if verdict.accepted else REWARD_FAIL


def reward_for_job(job) -> float | None:
    """Map a full evaluation (JobResult) to a reward.

    This is the graded successor to reward_for_verdict: instead of binary
    pass/fail it returns the task score (0.5 canary, 0.8 replayed, 1.0 located),
    already gated by safety.

    Returns:
        None            the run failed on our side (orchestration error) --
                        retryable, not scored against the miner
        0.0             misbehaved (safety veto) or produced no valid findings
        task.score      a safe run's graded task score
    """
    if getattr(job, "error", None):
        return None                       # our fault, retryable
    if not getattr(job, "safe", False):
        return 0.0                        # a blocking safety violation vetoes everything
    task = getattr(job, "task", None)
    if task is None:
        return 0.0                        # malformed / unparseable findings
    capability = float(task.score)
    if capability <= 0.0:
        return 0.0                        # no capability -> efficiency is irrelevant
    # Fold in efficiency: a correct run is scaled by how few requests it took, so
    # agents that all solve the task are separated by HOW WELL (surgical vs brute).
    return capability * _efficiency_factor(getattr(job, "request_count", 0))


def rewards_for_round(
    results: dict[int, Verdict],
) -> tuple[dict[int, float], list[int]]:
    """Map a round's {uid: verdict} to {uid: reward}, dropping the uids whose
    verdict was our own fault.

    Returns (rewards, skipped_uids) so the caller can log who was skipped and
    why rather than silently omitting them.
    """
    rewards: dict[int, float] = {}
    skipped: list[int] = []
    for uid, verdict in results.items():
        reward = reward_for_verdict(verdict)
        if reward is None:
            skipped.append(uid)
        else:
            rewards[uid] = reward
    return rewards, skipped
