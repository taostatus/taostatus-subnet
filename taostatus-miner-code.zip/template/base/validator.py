# The MIT License (MIT)
# Copyright © 2023 Yuma Rao
# TODO(developer): Set your name
# Copyright © 2023 <your name>

# Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
# documentation files (the “Software”), to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in all copies or substantial portions of
# the Software.

# THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
# THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.


import copy
import numpy as np
import asyncio
import argparse
import threading
import time
import traceback
import bittensor as bt

from typing import List, Union
from traceback import print_exception

from template.base.neuron import BaseNeuron
from template.base.utils.weight_utils import (
    process_weights_for_netuid,
    convert_weights_and_uids_for_emit,
)  # TODO: Replace when bittensor switches to numpy
from template.mock import MockDendrite
from template.utils.config import add_validator_args
from masxai import constants as C

BURN_UID = C.BURN_UID
BURN_PERCENTAGE = C.BURN_PERCENTAGE


def _apply_burn_allocation(
    current_uids: np.ndarray,
    weight_uids: np.ndarray,
    weights: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Reserve burn percentage for BURN_UID and scale miner weights down."""
    current_uids = np.asarray(current_uids)
    if BURN_UID not in current_uids.tolist():
        raise ValueError(
            f"BURN_UID {BURN_UID} is not present in current metagraph uids: "
            f"{current_uids.tolist()}"
        )

    if not 0.0 <= BURN_PERCENTAGE <= 1.0:
        raise ValueError(
            f"BURN_PERCENTAGE must be between 0.0 and 1.0, got {BURN_PERCENTAGE}"
        )

    weight_uids = np.asarray(weight_uids)
    weights = np.asarray(weights, dtype=np.float64)
    miner_percentage = 1.0 - BURN_PERCENTAGE

    miner_mask = weight_uids != BURN_UID
    miner_uids = weight_uids[miner_mask]
    miner_weights = weights[miner_mask]

    miner_sum = miner_weights.sum()
    if miner_uids.size > 0 and miner_sum > 0.0 and miner_percentage > 0.0:
        miner_weights = (miner_weights / miner_sum) * miner_percentage
        final_uids = np.append(miner_uids, BURN_UID)
        final_weights = np.append(miner_weights, BURN_PERCENTAGE)
    else:
        final_uids = np.asarray([BURN_UID])
        final_weights = np.asarray([1.0], dtype=np.float64)

    final_sum = final_weights.sum()
    if final_sum <= 0.0 or np.isnan(final_sum):
        raise ValueError(f"Final weights must sum to a positive value, got {final_sum}")
    final_weights = final_weights / final_sum
    return final_uids.astype(np.int64), final_weights.astype(np.float32)

class BaseValidatorNeuron(BaseNeuron):
    """
    Base class for Bittensor validators. Your validator should inherit from this class.
    """

    neuron_type: str = "ValidatorNeuron"

    @classmethod
    def add_args(cls, parser: argparse.ArgumentParser):
        super().add_args(parser)
        add_validator_args(cls, parser)

    def __init__(self, config=None):
        super().__init__(config=config)

        # Save a copy of the hotkeys to local memory.
        self.hotkeys = copy.deepcopy(self.metagraph.hotkeys)

        # Dendrite lets us send messages to other nodes (axons) in the network.
        if self.config.mock:
            self.dendrite = MockDendrite(wallet=self.wallet)
        else:
            self.dendrite = bt.Dendrite(wallet=self.wallet)
        bt.logging.info(f"Dendrite: {self.dendrite}")

        # Set up initial scoring weights for validation
        bt.logging.info("Building validation weights.")
        self.scores = np.zeros(self.metagraph.n, dtype=np.float32)

        # Say so loudly if this validator's mechanism does not exist on chain yet:
        # every weight set to it would be rejected until the subnet owner raises
        # the mechanism count (scripts/setup_mechanisms.py).
        self._check_mechanism_exists()

        # Init sync with the network. Updates the metagraph.
        self.sync()

        # Serve axon to enable external connections.
        if not self.config.neuron.axon_off:
            self.serve_axon()
        else:
            bt.logging.warning("axon off, not serving ip to chain.")

        # Create asyncio event loop to manage async tasks. Python 3.14 no
        # longer creates one implicitly for the main thread.
        try:
            self.loop = asyncio.get_event_loop()
        except RuntimeError:
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self.loop)

        # Instantiate runners
        self.should_exit: bool = False
        self.is_running: bool = False
        self.thread: Union[threading.Thread, None] = None
        self.lock = asyncio.Lock()

    def _check_mechanism_exists(self) -> None:
        """Warn (never fail) when this validator's mechid is not live on chain."""
        mechid = int(getattr(self, "mechid", 0) or 0)
        if mechid == 0 or self.config.mock:
            return
        try:
            count = int(self.subtensor.get_mechanism_count(netuid=self.config.netuid))
        except Exception as exc:  # noqa: BLE001 - a read failure is not fatal
            bt.logging.warning(f"could not read mechanism count: {exc}")
            return
        if mechid >= count:
            bt.logging.error(
                f"netuid {self.config.netuid} has {count} mechanism(s); mechanism "
                f"{mechid} does not exist yet, so this validator's weights will be "
                "rejected. The subnet owner must run scripts/setup_mechanisms.py."
            )
        else:
            bt.logging.info(
                f"validator bound to mechanism {mechid} of {count} on netuid {self.config.netuid}"
            )

    def _submit_weights(self, uids, weights):
        """Send the processed weights to this validator's mechanism.

        Mechanism 0 keeps the exact path it always had: Subtensor.set_weights,
        which retries and routes to commit-reveal when the subnet has it on.

        Any other mechanism goes straight to the extrinsic. Subtensor.set_weights
        guards its retry loop with blocks_since_last_update(netuid, uid), which
        reads LastUpdate for the bare netuid -- mechanism 0's row. With both
        validators on one hotkey, the mechanism-1 call would then be skipped as
        "too soon" whenever the LLM-key validator had just set weights. Our own
        pacing (_last_weight_update_block) already reads the right row, and the
        chain enforces the real per-mechanism rate limit either way.
        """
        mechid = int(getattr(self, "mechid", 0) or 0)
        if mechid == 0:
            return self.subtensor.set_weights(
                wallet=self.wallet,
                netuid=self.config.netuid,
                mechid=0,
                uids=uids,
                weights=weights,
                wait_for_finalization=True,
                wait_for_inclusion=True,
                version_key=self.spec_version,
            )

        from bittensor.core.extrinsics.weights import (
            commit_timelocked_weights_extrinsic,
            set_weights_extrinsic,
        )

        if self.subtensor.commit_reveal_enabled(netuid=self.config.netuid):
            return commit_timelocked_weights_extrinsic(
                subtensor=self.subtensor,
                wallet=self.wallet,
                netuid=self.config.netuid,
                mechid=mechid,
                uids=uids,
                weights=weights,
                block_time=12.0,
                version_key=self.spec_version,
                wait_for_inclusion=True,
                wait_for_finalization=True,
            )
        return set_weights_extrinsic(
            subtensor=self.subtensor,
            wallet=self.wallet,
            netuid=self.config.netuid,
            mechid=mechid,
            uids=uids,
            weights=weights,
            version_key=self.spec_version,
            wait_for_inclusion=True,
            wait_for_finalization=True,
        )

    def serve_axon(self):
        """Serve axon to enable external connections."""

        bt.logging.info("serving ip to chain...")
        try:
            self.axon = bt.Axon(wallet=self.wallet, config=self.config)

            try:
                self.subtensor.serve_axon(
                    netuid=self.config.netuid,
                    axon=self.axon,
                )
                bt.logging.info(
                    f"Running validator {self.axon} on network: {self.config.subtensor.chain_endpoint} with netuid: {self.config.netuid}"
                )
            except Exception as e:
                bt.logging.error(f"Failed to serve Axon with exception: {e}")
                pass

        except Exception as e:
            bt.logging.error(
                f"Failed to create Axon initialize with exception: {e}"
            )
            pass

    async def concurrent_forward(self):
        coroutines = [
            self.forward()
            for _ in range(self.config.neuron.num_concurrent_forwards)
        ]
        await asyncio.gather(*coroutines)

    def run(self):
        """
        Initiates and manages the main loop for the miner on the Bittensor network. The main loop handles graceful shutdown on keyboard interrupts and logs unforeseen errors.

        This function performs the following primary tasks:
        1. Check for registration on the Bittensor network.
        2. Continuously forwards queries to the miners on the network, rewarding their responses and updating the scores accordingly.
        3. Periodically resynchronizes with the chain; updating the metagraph with the latest network state and setting weights.

        The essence of the validator's operations is in the forward function, which is called every step. The forward function is responsible for querying the network and scoring the responses.

        Note:
            - The function leverages the global configurations set during the initialization of the miner.
            - The miner's axon serves as its interface to the Bittensor network, handling incoming and outgoing requests.

        Raises:
            KeyboardInterrupt: If the miner is stopped by a manual interruption.
            Exception: For unforeseen errors during the miner's operation, which are logged for diagnosis.
        """

        # Check that validator is registered on the network.
        self.sync()
        last_sync_block = self.block

        bt.logging.info(f"Validator starting at block: {self.block}")

        # This loop maintains the validator's operations until intentionally stopped.
        try:
            while not self.should_exit:
                current_block = self.block
                bt.logging.info(f"step({self.step}) block({current_block})")

                # Run multiple forwards concurrently.
                try:
                    self.loop.run_until_complete(self.concurrent_forward())
                except Exception:
                    bt.logging.error(traceback.format_exc())
                    time.sleep(12)
                    continue

                # Check if we should exit.
                if self.should_exit:
                    break

                # Sync metagraph and potentially set weights.
                try:
                    current_block = self.block
                    if (
                        current_block - last_sync_block
                        >= self.config.neuron.epoch_length
                    ):
                        self.sync()
                        last_sync_block = current_block
                except Exception:
                    bt.logging.error(traceback.format_exc())
                    time.sleep(12)

                self.step += 1

        # If someone intentionally stops the validator, it'll safely terminate operations.
        except KeyboardInterrupt:
            self.axon.stop()
            bt.logging.success("Validator killed by keyboard interrupt.")
            exit()

        # In case of unforeseen errors, the validator will log the error and continue operations.
        except Exception as err:
            bt.logging.error(f"Error during validation: {str(err)}")
            bt.logging.debug(
                str(print_exception(type(err), err, err.__traceback__))
            )

    def run_in_background_thread(self):
        """
        Starts the validator's operations in a background thread upon entering the context.
        This method facilitates the use of the validator in a 'with' statement.
        """
        if not self.is_running:
            bt.logging.debug("Starting validator in background thread.")
            self.should_exit = False
            self.thread = threading.Thread(target=self.run, daemon=True)
            self.thread.start()
            self.is_running = True
            bt.logging.debug("Started")

    def stop_run_thread(self):
        """
        Stops the validator's operations that are running in the background thread.
        """
        if self.is_running:
            bt.logging.debug("Stopping validator in background thread.")
            self.should_exit = True
            self.thread.join(5)
            self.is_running = False
            bt.logging.debug("Stopped")

    def __enter__(self):
        self.run_in_background_thread()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        """
        Stops the validator's background operations upon exiting the context.
        This method facilitates the use of the validator in a 'with' statement.

        Args:
            exc_type: The type of the exception that caused the context to be exited.
                      None if the context was exited without an exception.
            exc_value: The instance of the exception that caused the context to be exited.
                       None if the context was exited without an exception.
            traceback: A traceback object encoding the stack trace.
                       None if the context was exited without an exception.
        """
        if self.is_running:
            bt.logging.debug("Stopping validator in background thread.")
            self.should_exit = True
            self.thread.join(5)
            self.is_running = False
            bt.logging.debug("Stopped")

    def set_weights(self):
        """
        Sets the validator weights to the metagraph hotkeys based on the scores it has received from the miners. The weights determine the trust and incentive level the validator assigns to miner nodes on the network.
        """

        # Check if self.scores contains any NaN values and log a warning if it does.
        if np.isnan(self.scores).any():
            bt.logging.warning(
                f"Scores contain NaN values. This may be due to a lack of responses from miners, or a bug in your reward functions."
            )

        # Calculate the average reward for each uid across non-zero values.
        # Replace any NaN values with 0.
        # Compute the norm of the scores
        norm = np.linalg.norm(self.scores, ord=1, axis=0, keepdims=True)

        # Check if the norm is zero or contains NaN values
        if np.any(norm == 0) or np.isnan(norm).any():
            norm = np.ones_like(norm)  # Avoid division by zero or NaN

        # Compute raw_weights safely
        raw_weights = self.scores / norm

        # Nobody has earned anything yet: no miner has a confirmed positive
        # efficiency score (see Validator._blended_weight_array).
        #
        # This must not fall through to process_weights_for_netuid below,
        # which answers an all-zero vector with "No non-zero weights
        # returning all ones" -- a uniform split. That would hand every
        # registered miner an equal share of the non-burn allocation purely
        # for being registered, which is exactly what this subnet's rule
        # forbids: weight is earned only through confirmed, reported usage
        # of a contributed key, never by registering or by answering the ask.
        #
        # With no earner, the entire allocation burns.
        # _apply_burn_allocation below already renders exactly this case --
        # a zero miner sum burns the whole allocation -- so the zeros are
        # passed straight through to it rather than reimplemented here.
        no_earners = not np.any(raw_weights > 0)
        if no_earners:
            bt.logging.info(
                "no miner has a confirmed usage score; burning the full "
                "allocation rather than splitting it uniformly"
            )
            processed_weight_uids = np.asarray(self.metagraph.uids)
            processed_weights = np.zeros(len(processed_weight_uids), dtype=np.float32)
        else:
            bt.logging.debug("raw_weights", raw_weights)
            bt.logging.debug("raw_weight_uids", str(self.metagraph.uids.tolist()))
            # Process the raw weights to final_weights via subtensor limitations.
            (
                processed_weight_uids,
                processed_weights,
            ) = process_weights_for_netuid(
                uids=self.metagraph.uids,
                weights=raw_weights,
                netuid=self.config.netuid,
                subtensor=self.subtensor,
                metagraph=self.metagraph,
            )
        bt.logging.debug("processed_weights", processed_weights)
        bt.logging.debug("processed_weight_uids", processed_weight_uids)

        try:
            (
                processed_weight_uids,
                processed_weights,
            ) = _apply_burn_allocation(
                current_uids=self.metagraph.uids,
                weight_uids=processed_weight_uids,
                weights=processed_weights,
            )
        except ValueError as e:
            bt.logging.error(f"burn allocation failed; skipping set_weights: {e}")
            return
        bt.logging.debug("burn_allocated_weights", processed_weights)
        bt.logging.debug("burn_allocated_weight_uids", processed_weight_uids)

        # Convert to uint16 weights and uids.
        (
            uint_uids,
            uint_weights,
        ) = convert_weights_and_uids_for_emit(
            uids=processed_weight_uids, weights=processed_weights
        )
        bt.logging.debug("uint_weights", uint_weights)
        bt.logging.debug("uint_uids", uint_uids)

        # Temporary logging showing UIDs, raw scores, and final normalized weights
        bt.logging.info(
            f"TEMPORARY WEIGHT LOGGING (mechanism {getattr(self, 'mechid', 0)}):\n"
            f"  UIDs: {uint_uids}\n"
            f"  Raw Scores: {self.scores.tolist()}\n"
            f"  Final Normalized Weights: {processed_weights.tolist()}\n"
            f"  Scaled Uint16 Weights: {uint_weights}"
        )

        # Set the weights on chain, on this validator's own mechanism. SDK
        # versions differ here: older releases returned (success, message),
        # while newer releases return an ExtrinsicResponse with a .success.
        response = self._submit_weights(uint_uids, uint_weights)
        result = getattr(response, "success", None)
        if result is None:
            try:
                result, msg = response
            except Exception:
                result = bool(response)
                msg = str(response)
        else:
            msg = (
                getattr(response, "message", None)
                or getattr(response, "error_message", None)
                or str(response)
            )

        if bool(result):
            bt.logging.info("set_weights on chain successfully!")
            return True
        else:
            bt.logging.error("set_weights failed", msg)
            return False

    def resync_metagraph(self):
        """Resyncs the metagraph and updates the hotkeys and moving averages based on the new metagraph."""
        bt.logging.info("resync_metagraph()")

        # Copies state of metagraph before syncing.
        previous_metagraph = copy.deepcopy(self.metagraph)

        # Sync the metagraph.
        self.metagraph.sync(subtensor=self.subtensor)

        # Check if the metagraph axon info has changed.
        if previous_metagraph.axons == self.metagraph.axons:
            return

        bt.logging.info(
            "Metagraph updated, re-syncing hotkeys, dendrite pool and moving averages"
        )
        # Zero out all hotkeys that have been replaced within overlapping range.
        overlap = min(len(self.hotkeys), len(self.metagraph.hotkeys))
        for uid in range(overlap):
            if self.hotkeys[uid] != self.metagraph.hotkeys[uid]:
                self.scores[uid] = 0

        # Resize scores to match current metagraph size (handle growth and shrink).
        if len(self.scores) != int(self.metagraph.n):
            new_scores = np.zeros((self.metagraph.n), dtype=self.scores.dtype)
            copy_len = min(len(self.scores), int(self.metagraph.n))
            new_scores[:copy_len] = self.scores[:copy_len]
            self.scores = new_scores

        # Update the hotkeys.
        self.hotkeys = copy.deepcopy(self.metagraph.hotkeys)

    def update_scores(self, rewards: np.ndarray, uids: List[int]):
        """Performs exponential moving average on the scores based on the rewards received from the miners."""

        # Check if rewards contains NaN values.
        if np.isnan(rewards).any():
            bt.logging.warning(f"NaN values detected in rewards: {rewards}")
            # Replace any NaN values in rewards with 0.
            rewards = np.nan_to_num(rewards, nan=0)

        # Ensure rewards is a numpy array.
        rewards = np.asarray(rewards)

        # Check if `uids` is already a numpy array and copy it to avoid the warning.
        if isinstance(uids, np.ndarray):
            uids_array = uids.copy()
        else:
            uids_array = np.array(uids)

        # Handle edge case: If either rewards or uids_array is empty.
        if rewards.size == 0 or uids_array.size == 0:
            bt.logging.info(f"rewards: {rewards}, uids_array: {uids_array}")
            bt.logging.warning(
                "Either rewards or uids_array is empty. No updates will be performed."
            )
            return

        # Check if sizes of rewards and uids_array match.
        if rewards.size != uids_array.size:
            raise ValueError(
                f"Shape mismatch: rewards array of shape {rewards.shape} "
                f"cannot be broadcast to uids array of shape {uids_array.shape}"
            )

        # Compute forward pass rewards, assumes uids are mutually exclusive.
        # shape: [ metagraph.n ]
        scattered_rewards: np.ndarray = np.zeros_like(self.scores)
        scattered_rewards[uids_array] = rewards
        bt.logging.debug(f"Scattered rewards: {rewards}")

        # Update scores with rewards produced by this step.
        # shape: [ metagraph.n ]
        alpha: float = self.config.neuron.moving_average_alpha
        self.scores: np.ndarray = (
            alpha * scattered_rewards + (1 - alpha) * self.scores
        )
        bt.logging.debug(f"Updated moving avg scores: {self.scores}")

    def save_state(self):
        """Saves the state of the validator to a file."""
        bt.logging.info("Saving validator state.")

        # Save the state of the validator to file.
        np.savez(
            self.config.neuron.full_path + "/state.npz",
            step=self.step,
            scores=self.scores,
            hotkeys=self.hotkeys,
        )

    def load_state(self):
        """Loads the state of the validator from a file."""
        bt.logging.info("Loading validator state.")

        # Load the state of the validator from file.
        state = np.load(self.config.neuron.full_path + "/state.npz")
        self.step = state["step"]
        self.scores = state["scores"]
        self.hotkeys = state["hotkeys"]
