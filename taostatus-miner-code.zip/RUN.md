# TaoStatus — quick start (dual-mechanism, MAINNET SN104)

Two mechanisms, each run as its own process (same wallet + netuid):
- mech 0 — LLM-key   (neurons/validator.py / neurons/miner.py)
- mech 1 — security  (neurons/security_validator.py / neurons/security_miner.py)

## 0. The env files (sent SEPARATELY — they hold secrets)
Drop `validator.env` and/or `miner.env` into this folder (you received them
separately, not inside this zip). Fill in: your wallet, your public IP, and your
keys. Keep them private; never commit or share publicly.

## 1. Setup
```bash
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
python scripts/patch_btcli_compat.py
```
Mechanism 1 (security) also needs, on the box:
- Docker + gVisor runtime (runsc)
- `docker pull ghcr.io/adtao26/secval-ref-agent:v2`  (or build/ship your own agent)

## 2. Register your hotkey on netuid 104 (gets you a uid)
```bash
btcli subnet register --netuid 104 --subtensor.network finney \
  --wallet.name <YOUR_COLDKEY> --wallet.hotkey <YOUR_HOTKEY>
```
(Registration costs TAO.)

## 3. Run — VALIDATOR (two processes, load validator.env first)
```bash
# mech 0 (LLM-key)
python neurons/validator.py \
  --netuid 104 --subtensor.network finney \
  --wallet.name <CK> --wallet.hotkey <HK>

# mech 1 (security) — needs docker + gVisor
sg docker -c "python neurons/security_validator.py \
  --netuid 104 --subtensor.network finney \
  --wallet.name <CK> --wallet.hotkey <HK> --logging.debug"
```

## 3. Run — MINER (two processes, load miner.env first)
```bash
# mech 0 (LLM-key)
python neurons/miner.py \
  --netuid 104 --subtensor.network finney \
  --wallet.name <CK> --wallet.hotkey <HK> \
  --axon.port 8901 --axon.external_ip <YOUR_PUBLIC_IP>

# mech 1 (security)
sg docker -c "python neurons/security_miner.py \
  --netuid 104 --subtensor.network finney \
  --wallet.name <CK> --wallet.hotkey <HK> \
  --axon.port 8911 --axon.external_ip <YOUR_PUBLIC_IP> --logging.debug"
```

Tip: run each with pm2 so they stay up, e.g.
`pm2 start "..." --name sec-validator`.
